# CODSOFT
A repository containg the first task from my intenship in codsoft
The task is the classification of fradulant credit card transactions
